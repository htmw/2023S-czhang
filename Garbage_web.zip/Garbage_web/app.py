import base64
from flask import Flask, request, jsonify
import requests
import requests
import hashlib
import time

class TransApi:
    TRANS_API_HOST = "http://api.fanyi.baidu.com/api/trans/vip/translate"
    appid = "20220323001136298"
    securityKey = "YGGBj4nOcQyF0gVcCsN4"

    @staticmethod
    def getTransResultToEn(query):
        params = TransApi.buildParams(query, "auto", "en")
        json_str = requests.get(TransApi.TRANS_API_HOST, params=params).json()
        return json_str['trans_result'][0]['dst']

    @staticmethod
    def getTransResultToZh(query):
        params = TransApi.buildParams(query, "auto", "zh")
        json_str = requests.get(TransApi.TRANS_API_HOST, params=params).json()
        return json_str['trans_result'][0]['dst']

    @staticmethod
    def getTransResult(query, fromLang, toLang):
        params = TransApi.buildParams(query, fromLang, toLang)
        return requests.get(TransApi.TRANS_API_HOST, params=params).json()

    @staticmethod
    def buildParams(query, fromLang, toLang):
        salt = str(int(time.time() * 1000))
        sign = hashlib.md5((TransApi.appid + query + salt + TransApi.securityKey).encode('utf-8')).hexdigest()
        return {
            "q": query,
            "from": fromLang,
            "to": toLang,
            "appid": TransApi.appid,
            "salt": salt,
            "sign": sign
        }
    
app = Flask(__name__)

@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'POST'
    return response

@app.route('/search', methods=['POST'])
def search():
    url = 'http://apis.juhe.cn/voiceRubbish/search'
    key = '1113c947654337def72b0ca62b32300d'
    q = request.form['q']
    q = TransApi.getTransResultToZh(q)

    type = request.form['type']
    data = {'key': key, 'q': q, 'type': type}
    response = requests.post(url, data=data)
    json_obj = response.json()
    if json_obj['result'] is None:
        return jsonify(json_obj)
    
    for res in json_obj['result']:
        res['itemName'] = TransApi.getTransResultToEn(res['itemName'])
        res['itemCategory'] = TransApi.getTransResultToEn(res['itemCategory'])

    return jsonify(json_obj)

@app.route('/imgDisti', methods=['POST'])
def imgDisti():
    url = 'http://apis.juhe.cn/voiceRubbish/imgDisti'
    key = '1113c947654337def72b0ca62b32300d'
    image = request.files['image']
    type = request.form['type']

    image = base64.b64encode(image.read())

    data = {'key': key, 'type': type, 'image': image}

    response = requests.post(url, data=data)
    json_obj = response.json()
    if json_obj['result'] is None:
        return jsonify(json_obj)
    
    for res in json_obj['result']:
        if res['list'] is None:
            res['keyword'] = TransApi.getTransResultToEn(res['keyword'])
            continue
        for l in res['list']:
            l['itemName'] = TransApi.getTransResultToEn(l['itemName'])
            l['itemCategory'] = TransApi.getTransResultToEn(l['itemCategory'])

    return jsonify(json_obj)

if __name__ == '__main__':
    app.run()
    
