const searchInput = document.getElementById('searchInput');
const result = document.getElementById('result');
const imageInput = document.getElementById('imageInput');
const baseUrl = 'http://localhost:5000/';

async function searchByText() {
    const query = searchInput.value;
    if (!query) {
        alert('Please enter the name of the garbage you want to query');
        return;
    }

    const formData = new FormData();
    formData.append('q', query);
    formData.append('type', '1');

    try {
        displayResult('Loading...', 0);
        const response = await fetch(baseUrl + 'search', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();
        console.log(data);
        displayResult(data);
    } catch (error) {
        console.error('Error:', error);
    }
}

async function searchByImage() {
    const file = imageInput.files[0];
    if (!file) {
        alert('Please select an image');
        return;
    }

    result.innerHTML = `<img src="${imageInput.files[0].name}"/> <br>`;

    const reader = new FileReader();
    reader.onload = async function (event) {

        const formData = new FormData();
        formData.append('type', '1');
        formData.append('image', file);

        try {
            displayResult('Loading...', 0);
            const response = await fetch(baseUrl + 'imgDisti', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            console.log(data);
            displayResult(data);
        } catch (error) {
            console.error('Error:', error);
        }
    };
    reader.readAsDataURL(file);
}

function displayResult(data, type = 1) {
    if (type === 0) {
        result.innerHTML += data;
        result.innerHTML += '<br>';
        return;
    }

    if (data.error_code === 0 && data.result.length > 0) {
        if (data.result.length >= 1) {
            let resultText = '';
            data.result.forEach(item => {
                // 判断是否存在score
                if (item.score) {
                    if(item.list == null) {
                        resultText += `${item.keyword}, Score: ${item.score}<br>`;
                        return;
                    }
                    resultText += `${item.list[0].itemName}: ${item.list[0].itemCategory}, Score: ${item.score}<br>`;
                } else {
                    resultText += `${item.itemName}: ${item.itemCategory}<br>`;
                }
                
            });
            result.innerHTML += resultText;
            return;
        }
    } else {
        result.innerHTML += 'No relevant garbage classification information found';
    }
}
